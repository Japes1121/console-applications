package taxiBookingApp;


public class Executor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		BookTaxi bt=new BookTaxi();
		bt.initialTaxiStatus();
		bt.print();
		
		int stat=bt.bookTaxi(1, 'A', 'E', 8);
		if(stat>0){
			System.out.println("Taxi Can be alloted!");
			System.out.println("Taxi-"+stat+" allotted");
		}
		
		stat=bt.bookTaxi(2, 'C', 'D', 9);
		if(stat>0){
			System.out.println("Taxi Can be alloted!");
			System.out.println("Taxi-"+stat+" allotted");
		}

		stat=bt.bookTaxi(3, 'B', 'F', 10);
		if(stat>0){
			System.out.println("Taxi Can be alloted!");
			System.out.println("Taxi-"+stat+" allotted");
		}
		
		stat=bt.bookTaxi(4, 'A', 'C', 12);
		if(stat>0){
			System.out.println("Taxi Can be alloted!");
			System.out.println("Taxi-"+stat+" allotted");
		}
		
		stat=bt.bookTaxi(5, 'B', 'C', 8);
		if(stat>0){
			System.out.println("Taxi Can be alloted!");
			System.out.println("Taxi-"+stat+" allotted");
		}
	}

}
