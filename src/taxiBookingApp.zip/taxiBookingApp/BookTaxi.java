package taxiBookingApp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BookTaxi implements Properties {

	//private TaxiAppDAO taxiStatus=new TaxiAppDAO();
	//private TaxiEarningsDAO taxiEarnings=new TaxiEarningsDAO();
	
	//private static List<TaxiAppDAO> taxiStatus=new ArrayList<>();
	//	private static List<TaxiEarningsDAO> taxiEarnings=new ArrayList<>();
	private static HashMap<Integer,TaxiAppDAO> taxiStatus=new HashMap<>();
	private static HashMap<Integer,List<TaxiEarningsDAO>> taxiEarnings=new HashMap<>();

	
	public void initialTaxiStatus(){
		for(int i=0;i<Properties.taxi.length;i++){
			TaxiAppDAO taxi=new TaxiAppDAO();
			taxi.setBooked(false);
			taxi.setCurrentStop('A');
			taxi.setTaxi(Properties.taxi[i]);
			taxiStatus.put(taxi.getTaxi(),taxi);
		}
	}
	
	public void print(){
		TaxiAppDAO ta;
		for(Map.Entry m:taxiStatus.entrySet()){
			ta=(TaxiAppDAO) m.getValue();
			   System.out.println(m.getKey()+" "+ta.isBooked());  
			  }
		
	}
	
	public int bookTaxi(int custId, char pickupPoint, char dropPoint, int pickupTime){
		int noOfFreeTaxi=0;
		List<int[]> freeTaxiList=new ArrayList<>();
		int source,dest,earnings=0;
		TaxiAppDAO ta;
		TaxiEarningsDAO te;
		for(Map.Entry m:taxiStatus.entrySet()){  
			ta=(TaxiAppDAO) m.getValue();
			source=new String(Properties.endPoints1).indexOf(pickupPoint);
			dest=new String(Properties.endPoints1).indexOf(ta.getCurrentStop());
			
			if(ta.isBooked() == false && ta.isFirstTrip()==true){
				for(Map.Entry e:taxiEarnings.entrySet()){ 
					te=(TaxiEarningsDAO) m.getValue();
					System.out.println(te.getFareAmount());
				}
				noOfFreeTaxi=noOfFreeTaxi+1;
				int[] taxiStatus={ta.getTaxi(),Math.abs((source-dest)),earnings};
				freeTaxiList.add(taxiStatus);
				ta.setFirstTrip(false);
			}
			else if(ta.isBooked() == false && ta.getFreeTime() > pickupTime && ta.getPickupTime() < pickupTime){
				noOfFreeTaxi=noOfFreeTaxi+1;
				int[] taxiStatus={ta.getTaxi(),Math.abs((source-dest)),earnings};
				freeTaxiList.add(taxiStatus);
			}
		}
		
		for(int[] tas:freeTaxiList){
			System.out.println(tas[0] + " "+tas[1]);
		}
		
		TaxiAppDAO tass= new TaxiAppDAO();
		/*if(ta.isBooked()==false){
			ta.setBooked(true);
			TaxiEarningsDAO te=new TaxiEarningsDAO();		
			te.setCustomerId(custId);
			te.setStartPoint(pickupPoint);
			te.setEndPoint(dropPoint);
			te.setBookingId();
			te.setPickupTime(pickupTime);
			te.setFareAmount(calculateFare(pickupPoint, dropPoint)[0]);
			te.setDropTime((pickupTime+calculateFare(pickupPoint, dropPoint)[1]));
			te.setTaxi(ta.getTaxi());
			ta.setBooked(true);
			return te.getTaxi();
		}*/
		return 0;
		
	}
	
	public int[] calculateFare(char pickupPoint,char dropPoint){
		//Drop time and fare calculation
		int[] out=new int[2];
		int fare=0;
		int startIndex=new String(Properties.endPoints1).indexOf(pickupPoint);
		int endIndex=new String(Properties.endPoints1).indexOf(dropPoint);
		
		int distance=((endIndex-startIndex)*15)-5;
		fare=100+distance*10;
		out[0]=fare;
		out[1]=distance;
		return out;
	}
	
}
